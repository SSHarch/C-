#include <iostream>

class Taco {
public:
  std::string toping1;
  std::string toping2;

  Taco() {}
  Taco(std::string toping1) { this->toping1 = toping1; }

  Taco(std::string toping1, std::string toping2) {
    this->toping1 = toping1;
    this->toping2 = toping2;
  }
};

int main() {

  Taco taco1;
  Taco taco2("Tomato");
  Taco taco3("Macaroni", "cheese");
}
