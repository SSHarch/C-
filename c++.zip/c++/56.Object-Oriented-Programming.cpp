#include <iostream>

class Cat {
public:
  std::string name;
  std::string colors;
  int age;
  std::string gender;

  void eat() { std::cout << name << " is eating\n"; }

  void purr() { std::cout << name << " is purring\n"; }

  void shit() { std::cout << name << " is shiting\n"; }
};

int main() {

  Cat cat1;

  cat1.name = "Mufi";
  cat1.colors = "black and white";
  cat1.age = 4;
  cat1.gender = "male";

  std::cout << cat1.name << '\n';
  std::cout << cat1.colors << '\n';
  std::cout << cat1.age << '\n';
  std::cout << cat1.gender << '\n';

  cat1.shit();
  cat1.purr();
  cat1.eat();

  return 0;
}
