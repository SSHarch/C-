#include <iostream>

void carInfo(const int &year, const std::string &model);

int main() {
  int year = 1989;
  std::string model = "NA";

  carInfo(year, model);

  return 0;
}

void carInfo(const int &year, const std::string &model) {
  std::cout << "The specified car started prodcution in " << year
            << " and it was the " << model << " model\n";
}
