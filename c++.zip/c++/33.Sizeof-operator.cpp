#include <iostream>

int main()
{

std::string name = "Vroom vroom\n";

char grade = 'A';

bool orthodox = true;

double gpa = 2.5;

char Note[] = {'1', '2', '3', '4', '5', '6', '7', '8'};

std::string Copchii_zampada[] = {"Lucian", "Ion", "Dani", "Maxim", "Stefan"};

	
std::cout << sizeof(gpa) << " bytes\n";
std::cout << sizeof(orthodox) << " bytes\n";
std::cout << sizeof(grade) << " bytes\n";
std::cout << sizeof(name) << " bytes\n";
std::cout << sizeof(Note) << " bytes\n";

std::cout << sizeof(Note)/sizeof(char) << " bytes\n";

std::cout << sizeof(Copchii_zampada)/sizeof(std::string) << " copilasi\n";

	return 0;
}	
