#include <iostream>

int main() {

	int num;
	int guess;
	int tries = 0;

	srand(time(NULL));
	num = (rand() % 100) + 1;

	std::cout << "******************************************\n";
	do{
		std::cout << "Enter a number between 1-100: \n";
		std::cin >> guess;
		tries++;
		if (guess < num){
			std::cout << "Too low\n";
		}
		else if (guess > num){
			std::cout << "Too high\n";
		}	
		else{
			std::cout << "Correct!\n";
			std::cout << "**********************farts**********************\n";
			std::cout << tries << "tries\n";

		}	
	} while (num != guess); 	

	return 0;
}	
