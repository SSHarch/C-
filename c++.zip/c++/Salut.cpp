#include <iostream>

int main()
{
std::cout << "Salut!";

return 0;
}
