#include <ctime>
#include <iostream>

int main() {
  srand(time(0));
  int randNum = rand() % 5 + 1;

  switch (randNum) {
  case 1:
    std::cout << "You won a taste of freedom!\n";
    break;
  case 2:
    std::cout << "You won 5 bucks!\n";
    break;
  case 3:
    std::cout << "You won a church icon!\n";
    break;
  case 4:
    std::cout << "You won a Niva's door!\n";
    break;
  case 5:
    std::cout << "You won a Sony gift card!\n";
    break;
  }
  return 0;
}
