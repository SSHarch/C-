#include <iostream> 

int main()
{
    for(int i = 0; i >= 1000000; i++){
        std::cout << i << '\n';
    }

    return 0;

}