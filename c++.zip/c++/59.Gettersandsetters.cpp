#include <iostream>

class Engine {
private:
  int Maxrpm = 0;

public:
  int getMaxrmp() { return Maxrpm; }
  void setMaxrmp(int Maxrpm) {
    if (Maxrpm > 12000) {
      this->Maxrpm = 12000;
    } else if (Maxrpm < 0) {
      this->Maxrpm = 0;
    } else {
      this->Maxrpm = Maxrpm;
    }
  }
};

int main() {

  Engine engine1;

  engine1.setMaxrmp(11500);

  std::cout << engine1.getMaxrmp();
}
