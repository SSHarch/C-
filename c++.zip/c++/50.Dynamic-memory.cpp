#include <cstddef>
#include <iostream>

int main() {
  char *pCars = NULL;
  int carNum;

  std::cout << "How many cars do ya know?\n";
  std::cin >> carNum;

  pCars = new char[carNum];

  for (int i = 0; i < carNum; i++) {
    std::cout << "Enter Car initial " << i + 1 << '\n';
    std::cout << pCars[i];
  }

  for (int i = 0; i < carNum; i++) {
    std::cout << pCars[i];
  }

  delete pCars;

  return 0;
}
