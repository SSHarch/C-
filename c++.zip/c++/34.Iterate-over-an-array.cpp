#include <iostream>

int main(){
	std::string students[] = {"Jackie Chan", "Bruce Lee"};

	for(int i = 0; i < sizeof(students)/sizeof(std::string); i++){
		std::cout << students[i] << '\n';
	}
	return 0;
}	
