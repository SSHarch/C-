#include <iostream>

enum Library { raylib, sdl, opengl, pygame, ncurses };

int main() {

  Library curentlyUsed = sdl;

  switch (curentlyUsed) {
  case raylib:
    std::cout << "Curently using raylib\n";
    break;
  case sdl:
    std::cout << "Curently using sdl\n";
    break;
  case opengl:
    std::cout << "Curently using opengl\n";
    break;
  case pygame:
    std::cout << "Curently using pygame\n";
    break;
  case ncurses:
    std::cout << "Curently using ncurses\n";
    break;
  }
}
