#include <iostream>	

void happyBirthday(std::string name, int age);

int main()
{
	std::string name;
	int age = 0;

	std::cout << "Enter your name: \n";
	std::cin >> name;
	std::cout << "Enter your age: \n";
	std::cin >> age;

	happyBirthday(name, age);

	return 0;
}

void happyBirthday(std::string name, int age)
{
	std::cout << "Happy birthday " << name << '\n';
	std::cout << "Happy birthday dear " << name << '\n';
	std::cout << "Happy " << age << " years!" << '\n';
}	

