#include <iostream>

struct Stroika {
  std::string nume;
  int salariu;
  double experienta;
  std::string experienta2;
};

int main() {

  Stroika TemuProduction;
  TemuProduction.nume = "Ching chong";
  TemuProduction.salariu = -100000000;
  TemuProduction.experienta = 3.5;
  TemuProduction.experienta2 = "zile";

  std::cout << TemuProduction.nume << '\n';
  std::cout << TemuProduction.salariu << '\n';
  std::cout << TemuProduction.experienta << '\n';
  std::cout << TemuProduction.experienta2 << '\n';
}
