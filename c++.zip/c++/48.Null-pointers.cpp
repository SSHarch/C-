#include <iostream>

int main() {
  int *pointer = nullptr;
  int x = 123;

  pointer = &x;

  if (pointer == nullptr) {
    std::cout << "Failed assigning a value\n";
  } else {
    std::cout << "Succesfully assigned value " << *pointer << '\n';
  }
  return 0;
}
