#include <iostream>
#include <type_traits>
int math(int num) {
  int result = 1;
  for (int i = 1; i <= num; i++) {
    result = result * i;
  }
  return result;
}

int main() {
  std::cout << math(10);

  return 0;
}
