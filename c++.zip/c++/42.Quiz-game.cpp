#include <iostream>

int main() {
  std::string questions[] = {
      "When is your dads bday?: ", "When is your moms bday?: ",
      "At what age did you finish learning C++?: ", "Name 3 c++ libraries"};
  std::string options[][4] = {{"A.1981", "B.1985", "C.1983", "D.1982"},
                              {"A.1985", "B.1990", "C.1895", "D.1984"},
                              {"A.12", "B.13", "C.14", "D.11"},
                              {"A.sdl,opengl,raylib", "B.sdl,lua",
                               "C.pygame,sdl,raylib", "D.c#,python,java"}};

  char answerKey[] = {'A', 'A', 'A', 'A'};

  int size = sizeof(questions) / sizeof(questions[0]);
  char guess;
  int score;

  for (int i = 0; i < size; i++) {
    std::cout << questions[i] << '\n';

    for (int j = 0; j < sizeof(options[i]) / sizeof(options[i][0]); j++) {
      std::cout << options[i][j] << '\n';
    }

    std::cin >> guess;
    guess = toupper(guess);

    if (guess == answerKey[i]) {
      std::cout << "Correct!\n";
      score++;
    } else {
      std::cout << "Wrong!\n";
      std::cout << answerKey[i] << '\n';
    }
  }

  std::cout << "Results\n";
  std::cout << "corect guesses: " << score << '\n';
  std::cout << "# of questions: " << size << '\n';
  std::cout << "Score: " << (score / (double)size) * 100 << "%";
  return 0;
}
