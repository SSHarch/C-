#include <iostream>

class Cat {
public:
  std::string name;
  std::string colors;
  int age;
  std::string gender;

  void eat() { std::cout << name << " is eating\n"; }

  void purr() { std::cout << name << " is purring\n"; }

  void shit() { std::cout << name << " is shiting\n"; }

  Cat(std::string name, std::string colors, int age, std::string gender) {
    this->name = name;
    this->colors = colors;
    this->age = age;
    this->gender = gender;
  }
};

int main() {

  Cat cat1("Guts", "gray", 1, "male");
  Cat cat2("Leo", "Gray with white socks", 1, "male");
  Cat cat3("Bingo", "Gray with yellow", 1, "female");
  Cat cat4("Garfield", "Yellow", 1, "male");

  std::cout << cat1.name << '\n';
  std::cout << cat1.colors << '\n';
  std::cout << cat1.age << '\n';
  std::cout << cat1.gender << '\n';

  cat1.shit();
  cat1.purr();
  cat1.eat();

  std::cout << cat2.name << '\n';
  std::cout << cat2.colors << '\n';
  std::cout << cat2.age << '\n';
  std::cout << cat2.gender << '\n';

  cat2.shit();
  cat2.purr();
  cat2.eat();

  std::cout << cat3.name << '\n';
  std::cout << cat3.colors << '\n';
  std::cout << cat3.age << '\n';
  std::cout << cat3.gender << '\n';

  cat3.shit();
  cat3.purr();
  cat3.eat();

  std::cout << cat4.name << '\n';
  std::cout << cat4.colors << '\n';
  std::cout << cat4.age << '\n';
  std::cout << cat4.gender << '\n';

  cat4.shit();
  cat4.purr();
  cat4.eat();

  return 0;
}
