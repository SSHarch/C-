#include <iostream>
#include <utility>

struct Motorcycle {
  std::string model;
  int year;
  int cubicCentimeters;
};
void engineUpgrade(Motorcycle &motorcycle, int cubicCentimeters);
void printMotorcycle(Motorcycle &motorcycle);
int main() {

  Motorcycle yamaha;
  Motorcycle kawasaki;

  yamaha.model = "YZ125";
  yamaha.year = 1974;
  yamaha.cubicCentimeters = 125;

  kawasaki.model = "Ninja® ZX™-6R";
  kawasaki.year = 1995;
  kawasaki.cubicCentimeters = 636;

  printMotorcycle(yamaha);

  engineUpgrade(yamaha, 125);

  printMotorcycle(yamaha);

  return 0;
}
void printMotorcycle(Motorcycle &motorcycle) {
  std::cout << &motorcycle << '\n';
  std::cout << motorcycle.model << '\n';
  std::cout << motorcycle.year << '\n';
  std::cout << motorcycle.cubicCentimeters << '\n';
}
void engineUpgrade(Motorcycle &motorcycle, int cubicCentimeters) {
  motorcycle.cubicCentimeters = cubicCentimeters + 200;
}
