#include <iostream>
#include <string>

int main()
{
	std::string x {"2"};
	std::string y {"3"};
	std::cout << "2 + 3 = " << x + y << '\n';

	return 0;
}
