#include <iostream>

int main()
{	
	int size;
	std::cout << "Enter a number of animals: ";
	std::cin >> size;


	std::string animals[size];

	fill(animals, animals +(size/3), "cat");
	fill(animals + (size/3), animals +(size/3)*2, "dog");
	fill( animals + (size/3)*2, animals + size, "Galbenus");	
	for(std::string animal : animals){
		std::cout << animal <<'\n';
	}
	return 0;

}
