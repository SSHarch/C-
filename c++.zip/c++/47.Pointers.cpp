#include <iostream>

int main() {

  std::string language = "c++";
  char fart = 'F';
  std::string action = "shiting";

  std::string *paction = &action;

  std::cout << *paction;

  return 0;
}
