#include<iostream>

int main()
{
	std::string animals[11];
	int size = sizeof(animals)/sizeof(animals[0]);	
	std::string temp;

	for(int i = 0; i < size; i++){
		std::cout << "Enter a animals name or 'q' to quit  #" << i + 1 << ": ";
		std::getline(std::cin, temp);
		if(temp == "q"){
			break;
		}
		else{
			animals[i] = temp;
		}
	}
	std::cout << "You entered the following names:\n";

	for(int i = 0; !animals[i].empty(); i++){
	std::cout << animals << '\n';
	}
	return 0;
}
