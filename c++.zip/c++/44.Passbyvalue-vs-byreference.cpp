#include <iostream>

void swapschools(std::string &kikyo, std::string &chidori);

int main() {
  std::string kikyo = "Waguri";
  std::string chidori = "Rintaro";

  swapschools(kikyo, chidori);

  std::cout << "kikyo student: " << kikyo << '\n';
  std::cout << "chidori student: " << chidori << '\n';

  return 0;
}

void swapschools(std::string &kikyo, std::string &chidori) {
  std::string temp;
  temp = kikyo;
  kikyo = chidori;
  chidori = temp;
}
