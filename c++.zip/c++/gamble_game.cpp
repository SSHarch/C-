#include <ctime>
#include <iostream>
 int main() 
{
	srand(time(NULL));

	int num = 0;
	int randnum = (rand() % 2 ) + 1;

	std::cout << "Do you wish to bet:" << '\n';
	std::cout << "1.Red" << '\n';
	std::cout << "2.Black" << '\n';
	std::cin >> num;

	if(num == randnum){
		std::cout << "You've won!" << '\n';
        }
	else{
		std::cout << "You've lost 1 milion $" << '\n';
	}		
	return 0;
}	
