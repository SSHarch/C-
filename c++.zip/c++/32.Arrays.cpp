#include <iostream>

int main()
{

	std::string cars[] ={"Corvette", "Audi", "Miata"};

	cars[0] = "Shitbox(hell yeah)\n";

	std::cout << cars[0] <<'\n';

	std::string tractors[3];

	tractors[1] = "kirovets\n";

	double prices[] = {5.00, 7.50, 9.99, 15.00};

	std::cout << prices[3];

	return 0;
}	
