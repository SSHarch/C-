#include <iostream>

int main() {

	std::string rockband = "Alternosfera";
	int fartNumber = 21;	
	bool shit = true;

	std::cout << &rockband << '\n';
	std::cout << &fartNumber << '\n';
	std::cout << &shit << '\n';

	return 0;
}
