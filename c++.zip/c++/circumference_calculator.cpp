#include <iostream>
#include <cmath>

class Circle {
private:
    double radius;

public:
    // Constructor to initialize the radius
    Circle(double r) : radius(r) {}

    // Method to calculate circumference
    double circumference() const {
        const double PI = 3.14159265358979323846;
        return radius * PI * 2;
    }
};

int main() {
    double radius;
    std::cout << "Enter your radius: ";
    std::cin >> radius;

    Circle myCircle(radius);
    double result = myCircle.circumference();

    std::cout << "The circumference is " << result << '\n';
    return 0;
} 
